<?php

require_once "init.php";

$smarty->display('index.tpl');
?>
