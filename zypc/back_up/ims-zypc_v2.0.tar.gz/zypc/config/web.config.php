<?php

// define the allow agent ip
$ALLOW_HOST = array('222.24.24.*','127.0.0.*');

?>
