-- MySQL dump 10.13  Distrib 5.6.28, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: zypc_db
-- ------------------------------------------------------
-- Server version	5.6.28-1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asseing`
--

DROP TABLE IF EXISTS `asseing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asseing` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `pubdate` varchar(20) NOT NULL,
  `last_sum` varchar(200) NOT NULL,
  `this_play` varchar(200) NOT NULL,
  `detial_play` text NOT NULL,
  `admin_rate` varchar(200) DEFAULT NULL,
  `admin_rank` varchar(5) DEFAULT NULL,
  `timelong` varchar(10) DEFAULT NULL,
  `admin_flag` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asseing`
--

LOCK TABLES `asseing` WRITE;
/*!40000 ALTER TABLE `asseing` DISABLE KEYS */;
INSERT INTO `asseing` VALUES (1,'04131096','2016-05-02 12:34','这是一些上次的总结','这是本次总结概述','这是本次总结详细：\r\n1. 范儿国际能客人三个人个人个人；\r\n2. 而非染发膏使得但是第三个；\r\n3. 个人二恶二广东省的所发生的水电费。','基本还算合格，在基础方面多加用功','A+','76',0);
/*!40000 ALTER TABLE `asseing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signing`
--

DROP TABLE IF EXISTS `signing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signing` (
  `uid` int(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `stime` int(11) NOT NULL,
  `etime` int(11) NOT NULL,
  `dates` varchar(10) NOT NULL,
  `longs` int(11) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signing`
--

LOCK TABLES `signing` WRITE;
/*!40000 ALTER TABLE `signing` DISABLE KEYS */;
INSERT INTO `signing` VALUES (1,'04131096',1462185868,1462185868,'05-02',0),(2,'04131096',1462185870,1462185870,'05-02',0),(3,'04131096',1462185871,1462185871,'05-02',0),(4,'04131096',1462185902,1462185902,'05-02',0),(5,'04131096',1462185914,1462185914,'05-02',0),(6,'04131096',1462185973,1462185973,'05-02',0),(7,'04131096',1462185976,1462185976,'05-02',0),(8,'04131096',1462186036,1462186036,'05-02',0),(9,'04131096',1462186141,1462186141,'05-02',0),(10,'04131096',1462186142,1462186142,'05-02',0),(11,'04131096',1462186315,1462186315,'05-02',0),(12,'04131096',1462186466,1462186466,'05-02',0),(13,'04131096',1462186682,1462186682,'05-02',0),(14,'04131096',1462186819,1462187093,'05-02',274),(15,'04131096',1462187249,1462187382,'05-02',133),(16,'04131096',1462188112,1462188114,'05-02',2);
/*!40000 ALTER TABLE `signing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(40) NOT NULL,
  `nickname` varchar(40) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `mac_addr1` varchar(20) NOT NULL,
  `mac_addr2` varchar(20) NOT NULL,
  `permission` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'04131097','1122334455','测试者','test@test.com','18822226666','2214','234234324fgrtt','34fert435fr5g43',0),(3,'04131096','heheda','郭遗欢','s0nnet@qq.com','18829272629','东区2213','2cd05a6f92b0','28d24409fe67',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-03 14:22:47
